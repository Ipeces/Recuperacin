<?php
$jugar=true;
/*function comprobarsaldo(){
	// se comprueba que todos los jugadores tienen al menos 100€ sino no se juega 
	$saldo=fopen("./saldo.txt","r");
	while(!feof($saldo)){
		$linea=fgets($saldo);
		echo $linea;
	}
	fclose($saldo);
}

comprobarsaldo();*/
if($jugar==true){
	$ap1=$_POST['apuesta1'];
	$ap2=$_POST['apuesta2'];
	$ap3=$_POST['apuesta3'];
	$ap4=$_POST['apuesta4'];
$apuestas=array();
$baraja=array("1P","1D","1T","1C","2P","2D","2T","2C","3P","3D","3T","3C","4P","4D","4T","4C","5P","5D","5T","5C","6P","6D","6T","6C","7P","7D","7T","7C","8P","8D","8T","8C","9P","9D","9T","9C","10P","10D","10T","10C","JP","JD","JT","JC","QP","QD","QT","QC","KP","KD","KT","KC");
array_push($apuestas,$ap1);
array_push($apuestas,$ap1);
array_push($apuestas,$ap1);
array_push($apuestas,$ap1);
print_r($apuestas);
$mesa=array("J1"=>0,"J2"=>0,"J3"=>0,"J4"=>0,"banca"=>0);
function generarmesa($baraja){
shuffle($baraja);
//hACER ARRAY PARA APUNTAR LAS CARTAS comprobar 21

$contpuntos=0;
$cartas=array();
do{
$carta=array_pop ( $baraja ) ;
echo $carta;
$carta = substr($carta, 0, -1); 
	
		if($carta=="J"){
			$carta=11;
		}
		if($carta=="Q"){
			$carta=12;
		}
		if($carta=="K"){
			$carta=13;
		}
		if($carta==1){
			$carta=14;
		}
		
	array_push($cartas,$carta);
	
	echo $contpuntos."         ";
	print_r($cartas);
$contpuntos=calcularpuntos($cartas,$contpuntos);
echo "          ".$contpuntos;
$contpuntos++;
}while($contpuntos<=15);
echo $contpuntos."hola";
return $cartas;
}
function calcularpuntos($cartas,$contpuntos){
	foreach($cartas as $cartas){
	
	if ($cartas== 14){
		$contpuntos+11;
		echo "bFiguras";
		if ($contpuntos  >= 15&&$contpuntos<=21){
			
			
		}else {
			$contpuntos-10;}
	}else if($cartas>=11||$cartas<=13){
		$contpuntos+10;
		echo "figura uno";
	}else{
		$contpuntos=$cartas+$contpuntos;
		echo "no figura";
		
		}
	}
	return $contpuntos;
}

function modificarsaldos(){
	
//	se busca en el archivo saldo.txt y se mete en un array el cual contendra el saldo de cada uno y modificara segun lo que han ganado o apostado
	fopen("saldo.txt");
	feof();
	$saldo=fopen("saldo.txt","a");
  fwrite($sorteo,"Combinacion :");
foreach ($combinacionganadora as $comb) {
  fwrite($sorteo,$comb." ");
}
  fwrite($sorteo," ".PHP_EOL);

fclose($sorteo);
}


function mostrarcartas($mesa){
foreach ($mesa as $carta) {
	$ruta="images/$carta.png";
echo "<img src='$ruta'>"; 
}echo "</br>";
}


array_push($mesa,generarmesa($baraja,$mesa));
echo "</br>";
array_push($mesa,generarmesa($baraja,$mesa));
echo "</br>";
array_push($mesa,generarmesa($baraja,$mesa));
echo "</br>";
array_push($mesa,generarmesa($baraja,$mesa));
echo "</br>";
array_push($mesa,generarmesa($baraja,$mesa));
echo "</br>";
$puntuaciones=array();
mostrarcartas($mesa["banca"]);



	
}else { echo "No todos los jugadores tienen el dinero suficiente para jugar";}

?>